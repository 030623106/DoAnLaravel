@extends('layout.layout')
@section('content')

    <div id="templatemo_main_wrapper">
        <div id="templatemo_main">
            <div id="sidebar" class="left">
                <div class="sidebar_box"><span class="bottom"></span>
                    <h3>Categories</h3>
                    <div class="content">
                        <ul class="sidebar_list">
                            <li><a href="#">Nulla odio ipsum</a></li>
                            <li><a href="#">Suspendisse posuere</a></li>
                            <li><a href="#">Aliquam euismod</a></li>
                            <li><a href="#">Curabitur ac mauris</a></li>
                            <li><a href="#">Mauris nulla tortor</a></li>
                            <li><a href="#">Nullam ultrices</a></li>
                            <li><a href="#">Vivamus scelerisque</a></li>
                            <li><a href="#">Suspendisse posuere</a></li>
                            <li><a href="#">Quisque vel justo</a></li>
                        </ul>
                    </div>
                </div>
                <div class="sidebar_box"><span class="bottom"></span>
                    <h3>Weekly Special</h3>
                    <div class="content special">
                        <img src="images/templatemo_image_01.jpg" alt="Flowers" />
                        <a href="#">Citrus Burst Bouquet</a>
                        <p>
                            Price:
                            <span class="price normal_price">$160</span>&nbsp;&nbsp;
                            <span class="price special_price">$100</span>
                        </p>
                    </div>
                </div>
            </div>

            <div id="content" class="right">
                <h2>Shopping Cart</h2>
                <table width="700" border="0" cellpadding="5" cellspacing="0">
                    <tr bgcolor="#395015">
                        <th width="168" align="left">Item</th>
                        <th width="188" align="left">Description</th>
                        <th width="60" align="center">Quantity</th>
                        <th width="80" align="right">Price</th>
                        <th width="80" align="right">Total</th>
                        <th width="64"> </th>
                    </tr>
                    <tr bgcolor="#41581B">
                        <td><img src="images/product/01.jpg" alt="flower image 1" /></td>
                        <td>Ut eu feugiat</td>
                        <td align="center"><input name="quantity1" type="text" id="quantity1" value="1"
                                size="6" maxlength="2" /> </td>
                        <td align="right">$240</td>
                        <td align="right">$240</td>
                        <td align="center"> <a href="#"><img src="images/remove.png" alt="remove" /><br />Remove</a>
                        </td>
                    </tr>
                    <tr bgcolor="#41581B">
                        <td><img src="images/product/02.jpg" alt="flower image 2" /> </td>
                        <td>Donec Est Nisi (Validate <a href="http://validator.w3.org/check?uri=referer"
                                rel="nofollow"><strong>XHTML</strong></a> &amp; <a
                                href="http://jigsaw.w3.org/css-validator/check/referer"
                                rel="nofollow"><strong>CSS</strong></a>)</td>
                        <td align="center"><input name="quantity2" type="text" id="quantity2" value="2"
                                size="6" maxlength="2" /> </td>
                        <td align="right">$160</td>
                        <td align="right">$320</td>
                        <td align="center"> <a href="#"><img src="images/remove.png" alt="remove" /><br />Remove</a>
                        </td>
                    </tr>
                    <tr bgcolor="#41581B">
                        <td colspan="3">Have you modified item quantities? Please <a
                                href="shoppingcart.html"><strong>Update</strong></a> the Cart.&nbsp;&nbsp;</td>
                        <td align="right">
                            <h4>All Total:</h4>
                        </td>
                        <td align="right">
                            <h4>$560</h4>
                        </td>
                        <td> </td>
                    </tr>
                </table>
                <div class="cleaner h20"></div>
                <div class="right"><a href="checkout.html" class="button">checkout</a></div>
                <div class="cleaner h20"></div>
                <div class="blank_box">
                    <a href="#"><img src="images/free_shipping.jpg" alt="Free Shipping" /></a>
                </div>
            </div>
            <div class="cleaner"></div>
        </div> <!-- END of main -->
    </div> <!-- END of main wrapper -->



@endsection

